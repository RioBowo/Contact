package com.example.recycleview1.model;

public class Kontak {

    private int foto;
    private String nama;
    private String noTlp;
    private String email;

    public Kontak(int foto, String nama, String noTlp, String email) {
        this.foto = foto;
        this.nama = nama;
        this.noTlp = noTlp;
        this.email = email;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNoTlp() {
        return noTlp;
    }

    public void setNoTlp(String noTlp) {
        this.noTlp = noTlp;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
