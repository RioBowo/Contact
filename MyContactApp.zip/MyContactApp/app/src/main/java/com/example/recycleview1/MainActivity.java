package com.example.recycleview1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.recycleview1.adapter.KontakAdapter;
import com.example.recycleview1.model.Kontak;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RecyclerView recyclerView;
    KontakAdapter kontakRecyclerAdapter;
    ArrayList<Kontak> _kontakList;
    Button btnAddData;
    int[] foto ={R.drawable.ava1,R.drawable.ava2,R.drawable.ava3};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAddData = findViewById(R.id.btAddKontak);
        btnAddData.setOnClickListener(this);
        loadData();
        initRecyclerView();
    }


    private void initRecyclerView(){
       RecyclerView recyclerView = findViewById(R.id.recyclerView_id);
       kontakRecyclerAdapter = new KontakAdapter(_kontakList,this);
       recyclerView.setAdapter(kontakRecyclerAdapter);
       recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


    private void addData() {
        Random ran = new Random();
        int choose = ran.nextInt(3);
        _kontakList.add(new Kontak(foto[choose],"newData "+(_kontakList.size()-1),"08123456789"+(_kontakList.size()-1),"shifa@gmail.com"));
    }


    private void loadData(){


        _kontakList = new ArrayList<>();
        _kontakList.add(new Kontak(foto[0],"Shifa","081234567890","shifa@gmail.com"));
        _kontakList.add(new Kontak(foto[1],"Akbar","085648640046","akbar@gmail.com"));
        _kontakList.add(new Kontak(foto[2],"Budi","085648640047","budi@gmail.com"));

    }

    @Override
    public void onClick(View v) {
        if(v.getId()==btnAddData.getId())
        {
            addData();
            kontakRecyclerAdapter.notifyDataSetChanged();

        }
    }
}