package com.example.recycleview1.viewholder;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recycleview1.R;

public class KontakViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView _nama, _noHp;
    ImageView foto;
    Context _context;
    public KontakViewHolder(@NonNull View itemView) {
        super(itemView);
        _context = itemView.getContext();
        _nama = itemView.findViewById(R.id.txNama_id);

        _noHp = itemView.findViewById(R.id.txNoTelp_id);

        foto = itemView.findViewById(R.id.foto_id);
    }

    public TextView get_nama() {
        return _nama;
    }

    public TextView get_noHp() {
        return _noHp;
    }

    public ImageView getFoto() {
        return foto;
    }

    @Override
    public void onClick(View v) {

            Uri uri = Uri.parse("tel:"+ _noHp.getText().toString());
            Intent it = new Intent(Intent.ACTION_DIAL, uri);
            _context.startActivity(it);

    }
}
