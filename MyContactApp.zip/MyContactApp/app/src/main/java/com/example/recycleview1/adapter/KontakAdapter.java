package com.example.recycleview1.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.recycleview1.R;
import com.example.recycleview1.model.Kontak;
import com.example.recycleview1.viewholder.KontakViewHolder;

import java.util.ArrayList;

public class KontakAdapter  extends RecyclerView.Adapter<KontakViewHolder> {
    private ArrayList<Kontak> _kontakList;
    private Context context;

    public KontakAdapter(ArrayList<Kontak> itemList, Context context) {
        this._kontakList = itemList;
        this.context = context;
    }

    @NonNull
    @Override
    public KontakViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_item,parent, false);
        KontakViewHolder viewHolder = new KontakViewHolder(v);
        return viewHolder;
    }



    @Override
    public void onBindViewHolder(@NonNull KontakViewHolder holder, int position) {

        holder.get_nama().setText(_kontakList.get(position).getNama());
        Glide.with(context).load(_kontakList.get(position).getFoto()).into(holder.getFoto());
        holder.get_noHp().setText(_kontakList.get(position).getNoTlp());

    }

    @Override
    public int getItemCount() {
        return _kontakList.size();
    }
}
